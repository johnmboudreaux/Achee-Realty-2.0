import { combineReducers } from 'redux';
// import currentListings from './components/CurrentListings/Reducer';
import propertyDetails from './components/Search/Reducer';

export default combineReducers({
  // currentListings,
  propertyDetails,
});
