const key = 'X1-ZWz1gbl96or2ff_4ok8b'

module.exports = {
  key
}
